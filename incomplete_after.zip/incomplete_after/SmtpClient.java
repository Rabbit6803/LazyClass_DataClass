public class SmtpClient {
	public void send(String to, String subject, String body) {
		// implementation to send email using SMTP
		System.out.println("Sending email to " + to);
		System.out.println("Subject: " + subject);
		System.out.println("Body: " + body);
		System.out.println("Email sent successfully.");
	}
}